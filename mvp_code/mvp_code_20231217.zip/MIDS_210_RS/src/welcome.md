# PLODI - Pandemic Loan Outlier Detection and Indicators

This dashboard showcases the data and additional project details for the associated project ([Github Link Here](https://github.com/s-chadalavada/plodi/)) with this dashboard's ([Github Link Here](https://github.com/roberto-saldivar/MIDS_210_RS/tree/main))

# Team

This project was completed in Fall 2023 as part of the UC Berkeley MIDS W210 Session 9 Capstone. The team consists of the following UC Berkeley MIDS students: Roberto Salvidar - [roberto_saldivar@ischool.berkeley.edu](roberto_saldivar@ischool.berkeley.edu), Crystal Chen - [crystalqianchen@ischool.berkeley.edu](crystalqianchen@ischool.berkeley.edu), Mike Varner - [mike_varner@ischool.berkeley.edu](mike_varner@ischool.berkeley.edu), and Sridhar Chadalavada - [sridhar@ischool.berkeley.edu](sridhar@ischool.berkeley.edu)

