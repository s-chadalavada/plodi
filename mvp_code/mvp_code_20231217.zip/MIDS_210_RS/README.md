## Overview

This repo contains the code and notebooks for the [PLODI loan dashboards](https://fwgmq3bk6p.us-east-1.awsapprunner.com/). The primary website for the project is located at https://s-chadalavada.github.io/plodi/, and includes the background, model, results, and direct links to the final MVP. 
